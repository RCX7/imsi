% costFun.m
% Roger Chen
% 2026-06-30
% A cost function to minimize energy expenditure for trajectory
% optimization

function [cost] = costFun(w, mode, I)

    [~, states, addDecs] = decToMats(w);
    [N, ~] = simConstants();
    [xs, xdots, zs, zdots, ~] = extractStates(states);
    [xf, ~, ~, ~] = flightKinematics( ...
        xs(end), xdots(end), zs(end), zdots(end), addDecs(2));
    
    dist = xs(end) - xs(1);
    dtravel = xf - xs(1);
    % input 'r' for running, 'h' for hopping.
    swingCost = computeSwingWork(dist, addDecs(1), addDecs(2), mode, I, dtravel);
    stanceCost = trapz(addDecs(1), addDecs(3:2+N));
    cost = stanceCost + swingCost;
end