% physCconstants.m
% Roger Chen
% 2026-06-30
% Modularizing commonly used physicaal constants. Used in determining the
% kinematics of the simulation

function [m, g, k, c, la0, laRange, target_speed, target_freq, I, t_sim, l_uN]...
            = physConstants(mode)
    assert(mode == 'r' | mode == 'h')
    
    %% UNNORMALIZED DATA
    g_uN = 9.81;
    l_uN = 1.15;  % distance from COM to COP in meters
    target_speed_uN = 4;  % in meters per second
    target_freq_uN = 0;
    if mode == 'r', target_freq_uN = target_freq_uN * 2; end

    %% NORMALIZED DATA
    m = 1;
    g = 1;
    k = 30;
    % k = 42.389;  % running fit
    % k = 62.055;        % vertical stiffness fit
    c = 0.3;
    la0 = 1;
    t_sim = sqrt( l_uN / g_uN);  % unit of simulation time, in seconds
    target_freq = target_freq_uN * t_sim;
    
    laRange = 10; % kind of obsolete
    target_speed = target_speed_uN * (t_sim / l_uN);
    I = 0.0463; % maybe normalize somehow
    % I = 0.08;

    if mode == 'h'
        k = 22.141;
        % k = 31.0771;   % vertical stiffness fit
        c = 0.4;
        I = I*2;
    end
end