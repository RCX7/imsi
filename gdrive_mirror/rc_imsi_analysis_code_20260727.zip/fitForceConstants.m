% fitForceConstant.m
% Roger Chen
% 2026-07-17
% Plot force with respect to displacement to compute spring constant and
% normalize. (could possibly work on fitting a damping constant as well).
% As of 7/24/2026: Not built for maintainability and scalability

clc; clearvars; %close all;


%% set trial to fit
force_path = 'ForceData';
com_path = 'COM Trajectory';
trials = {'hop_1ms_4min'; 'run_1ms_4min'};
subject = 'S01';
gait = 'h';
speed = 1;
if gait == 'r', curr_trial = trials{2}; else, curr_trial = trials{1}; end
BW = 92.65;
fs = 2000;
fs_kin = 200; 
hip_height = 0.9;
g = 9.81;
ML = 1; AP = 2; VERT = 3;
threshold = 25;
belt_speed = 1.0;


%% extract data
force_data = importdata([force_path '\' curr_trial '.mot']);
pos_data = importdata([com_path '\' curr_trial '\' subject '_' curr_trial '_BodyKinematics_pos_global.sto']);
vel_data = importdata([com_path '\' curr_trial '\' subject '_' curr_trial '_BodyKinematics_vel_global.sto']);

t_kin  = pos_data.data(:,1);
t_for = force_data.data(:,1);

FxL = force_data.data(:,2);
FyL = force_data.data(:,4);
FzL = force_data.data(:,3);
F_left = [FxL, FyL, FzL];
FxR = force_data.data(:,11);
FyR = force_data.data(:,13);
FzR = force_data.data(:,12);
F_right = [FxR, FyR, FzR];
F_net = F_right + F_left;

ML = 1; AP = 2; VERT = 3; % for reference

Fc = 10;                % 10 Hz cutoff frequency
[b, a] = butter(4, Fc / (fs / 2), 'low');
smooth = @(data) filtfilt(b, a, data);

cop_x_L = force_data.data(:, 5);
cop_y_L = force_data.data(:, 7);
cop_z_L = force_data.data(:, 6);
cop_L = [cop_x_L, smooth(cop_y_L), cop_z_L];
cop_x_R = force_data.data(:, 14);
cop_y_R = force_data.data(:, 16);
cop_z_R = force_data.data(:, 15);
cop_R = [cop_x_R, smooth(cop_y_R), cop_z_R];

com_x = pos_data.data(:,86);
com_y = pos_data.data(:,88);
com_z = pos_data.data(:,87);
com_pos = [com_x, com_y, com_z];

com_pos = interp1(t_kin, com_pos, t_for, 'linear','extrap');

% normalized data
% com_pos_norm = rescale(com_pos, -1, 1, 'InputMin', min(com_pos, [], 1), 'InputMax', max(com_pos, [], 1));
% f_net_norm = rescale(F_net, 0, 1, "InputMin", min(F_net, [], 1), 'InputMax', max(F_net, [], 1));


%% compute displacements
R_dists = com_pos - cop_R;
L_dists = com_pos - cop_L;

R_dist_mags = vecnorm(R_dists, 2, 2);
L_dist_mags = vecnorm(L_dists, 2, 2);

L_dist_dirs = L_dists ./ L_dist_mags;
R_dist_dirs = R_dists ./ R_dist_mags;

% filter a bit
% threshold to remove random noise
threshold = prctile(L_dist_mags, 90);
L_dist_mags(L_dist_mags > threshold) = threshold;
filtered_L_dist_mags = smooth(L_dist_mags);
% F_left_norm = vecnorm(F_left, 2, 2);
F_left_norm = sum(F_left .* L_dist_dirs, 2);  % dot product take component of force in direction of COM-COP

threshold = prctile(R_dist_mags, 90);
R_dist_mags(R_dist_mags > threshold) = threshold;
filtered_R_dist_mags = smooth(R_dist_mags);
% F_right_norm = vecnorm(F_right, 2, 2);
F_right_norm = sum(F_right .* R_dist_dirs, 2);

% F_norm = vecnorm(F_net, 2, 2);
LR_dist_dirs = (L_dist_dirs .* R_dist_dirs);  % averge between the two..?
LR_dist_dirs = LR_dist_dirs ./ vecnorm(LR_dist_dirs, 2, 2);
F_norm = sum(F_net .* LR_dist_dirs, 2);

%% compute force and displacement
xL = filtered_L_dist_mags;
xR = filtered_R_dist_mags;

switch gait
    case 'r'    % foot by foot
        yL = F_left_norm;
        Lmask = yL > 50;
        xL = xL(Lmask);
        yL = yL(Lmask);

        yR = F_right_norm;
        Rmask = yR > 50;
        xR = xR(Rmask);
        yR = yR(Rmask);

    case 'h'
        x = (xL + xR) / 2;      % avg between legs for hopping distance
        y = F_norm;
        mask = y > 50;
        x = x(mask);
        y = y(mask);
end

%%  plot and do linear regression
hold on;
switch gait
    case 'r'
        plot(xL, yL);
        plot(xR, yR);

        %% linear regression
        [plin, ~] = polyfit(xL, yL, 1);
        mL = plin(1);
        bL = plin(2);
        plot(xL, (mL * xL + bL));
        
        [plin, ~] = polyfit(xR, yR, 1);
        mR = plin(1);
        bR = plin(2);
        plot(xR, (mR * xR + bR));
    case 'h'
        plot(x, y);

        [plin, ~] = polyfit(x, y, 1);
        m = plin(1);
        b = plin(2);
        plot(x, (m * x + b));
end
hold off;


%% extract and normalize
mode = "lr";  % linear regression
% mode = "res";  % resonant frequency

switch gait
    case 'r'
        switch mode
            case "lr"
                kL = mL;
                kR = mR;
            case "res"
                L_omega = (1 / mean()) * pi;
                kL = BW * (L_omega ^ 2);
                R_omega = (1 / mean()) * pi;
                kR = BW * (R_omega ^ 2);
        end

        kLnorm = (abs(kL) * max(xL)) / (BW * g);
        kRnorm = (abs(kR) * max(xR)) / (BW * g);
        avg_knorm = (kLnorm + kRnorm)/2;
        disp("Running constants ( " + mode +  " ):");
        fprintf("Left k: %.3f | Right k: %.3f | Avg k: %.3f\n", kLnorm, kRnorm, avg_knorm);
    case 'h'
        switch mode
            case "lr"
                k = m;
            case "res"
        end

        knorm = (abs(k) * max(x) / (BW * g));
        disp("Hopping constants ( " + mode + " ):");
        fprintf("k: %.3f\n", knorm);
end
